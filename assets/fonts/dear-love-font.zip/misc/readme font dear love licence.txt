

hi ;) please contact me for commercial / extended license.
email : studioaktype@gmail.com

this font for personal project , non-profit and charity use. 
but any donation are very appreciated

paypal account for donation : studioaktype@gmail.com

follow my instragram for update : @studioaktype
